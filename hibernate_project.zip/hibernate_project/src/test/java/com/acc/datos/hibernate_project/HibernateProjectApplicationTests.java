package com.acc.datos.hibernate_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
